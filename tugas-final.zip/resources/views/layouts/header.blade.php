<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>@yield('title', 'SIAKAD')</title>
    <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>

<body>

    <header class="header">
        <div class="header-container">

            <!-- Logo -->
            <a href="{{ url('/') }}" class="logo">
                <div class="logo-icon">S</div>

                <div class="logo-text">
                    <h1>SIAKAD</h1>
                    <span>Sistem Informasi Akademik</span>
                </div>
            </a>

            <!-- Navigation -->
            <nav class="navigation">
                <a class="{{ request()->routeIs('welcome') ? 'active' : '' }}" href="{{ route('welcome') }}">
                    Home
                </a>

                <a class="{{ request()->routeIs('mahasiswa.*') ? 'active' : '' }}" href="{{ route('mahasiswa.index') }}">
                    Mahasiswa
                </a>

                <a class="{{ request()->routeIs('dosen.*') ? 'active' : '' }}" href="{{ route('dosen.index') }}">
                    Dosen
                </a>

                <a class="{{ request()->routeIs('jurusan.*') ? 'active' : '' }}" href="{{ route('jurusan.index') }}">
                    Jurusan
                </a>

                <a class="{{ request()->routeIs('prodi.*') ? 'active' : '' }}" href="{{ route('prodi.index') }}">
                    Program Studi
                </a>

                <a class="{{ request()->routeIs('matakuliah.*') ? 'active' : '' }}" href="{{ route('matakuliah.index') }}">
                    Mata Kuliah
                </a>
                
                <a class="{{ request()->routeIs('ruang.*') ? 'active' : '' }}" href="{{ route('ruang.index') }}">
                    Ruangan
                </a>

                <a class="{{ request()->routeIs('login') ? 'active' : '' }}" href="{{ route('login') }}">
                    <i class="fa-solid fa-circle-user"></i>
                </a>
            </nav>

        </div>
    </header>


    <!-- Isi halaman -->
    <main class="main">
        @yield('content')
    </main>

    <footer class="footer">
        <p>&copy; {{ date('Y') }} SIAKAD &mdash; Sistem Informasi Akademik</p>
    </footer>

</body>
</html>