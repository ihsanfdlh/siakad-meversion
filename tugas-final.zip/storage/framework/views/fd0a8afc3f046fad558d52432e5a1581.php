
<?php $__env->startSection('judul', 'Detail Siswa - ' . $siswa->nama); ?>
<?php $__env->startSection('konten'); ?>
    <h1>Detail siswa</h1>
    <p><strong>NIM:</strong> <?php echo e($siswa->nim); ?></p>
    <p><strong>Nama:</strong> <?php echo e($siswa->nama); ?></p>
    <p><strong>Program Studi:</strong> <?php echo e($siswa->prodi); ?></p>
    <p><strong>Semester:</strong> <?php echo e($siswa->semester); ?></p>
    <a href="<?php echo e(route('akademik.siswa.index')); ?>">&laquo; Kembali ke Daftar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\siswa\show.blade.php ENDPATH**/ ?>