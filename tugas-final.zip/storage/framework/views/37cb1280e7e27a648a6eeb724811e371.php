<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>

<body>

    <h1>Dashboard</h1>

    <p>
        Selamat datang,
        <?php echo e(auth()->user()->name); ?>

    </p>

    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <button type="submit">
            Logout
        </button>
    </form>

</body>
</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\dashboard.blade.php ENDPATH**/ ?>