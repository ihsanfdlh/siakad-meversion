<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'SIAKAD'); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>

<body>

    <header class="header">
        <div class="header-container">

            <!-- Logo -->
            <a href="<?php echo e(url('/')); ?>" class="logo">
                <div class="logo-icon">S</div>

                <div class="logo-text">
                    <h1>SIAKAD</h1>
                    <span>Sistem Informasi Akademik</span>
                </div>
            </a>

            <!-- Navigation -->
            <nav class="navigation">
                <a class="<?php echo e(request()->routeIs('welcome') ? 'active' : ''); ?>" href="<?php echo e(route('welcome')); ?>">
                    Home
                </a>

                <a class="<?php echo e(request()->routeIs('mahasiswa.*') ? 'active' : ''); ?>" href="<?php echo e(route('mahasiswa.index')); ?>">
                    Mahasiswa
                </a>

                <a class="<?php echo e(request()->routeIs('dosen.*') ? 'active' : ''); ?>" href="<?php echo e(route('dosen.index')); ?>">
                    Dosen
                </a>

                <a class="<?php echo e(request()->routeIs('jurusan.*') ? 'active' : ''); ?>" href="<?php echo e(route('jurusan.index')); ?>">
                    Jurusan
                </a>

                <a class="<?php echo e(request()->routeIs('prodi.*') ? 'active' : ''); ?>" href="<?php echo e(route('prodi.index')); ?>">
                    Program Studi
                </a>

                <a class="<?php echo e(request()->routeIs('matakuliah.*') ? 'active' : ''); ?>" href="<?php echo e(route('matakuliah.index')); ?>">
                    Mata Kuliah
                </a>
                
                <a class="<?php echo e(request()->routeIs('ruang.*') ? 'active' : ''); ?>" href="<?php echo e(route('ruang.index')); ?>">
                    Ruangan
                </a>

                <a class="<?php echo e(request()->routeIs('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">
                    <i class="fa-solid fa-circle-user"></i>
                </a>
            </nav>

        </div>
    </header>


    <!-- Isi halaman -->
    <main class="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="footer">
        <p>&copy; <?php echo e(date('Y')); ?> SIAKAD &mdash; Sistem Informasi Akademik</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/layouts/header.blade.php ENDPATH**/ ?>