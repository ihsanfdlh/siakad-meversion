<!DOCTYPE html>
<html>
<head><title>Belajar Blade</title></head>
<body>
    
    <h1>Halo, <?php echo e($nama); ?>!</h1>

    <?php
        $tahunSekarang = date('Y');
    ?>

    <p>Tahun sekarang: <?php echo e($tahunSekarang); ?></p>
    <p>Julukan: <?php echo e($julukan ?? 'Belum ada julukan'); ?></p>

    <p>Escaped: <?php echo e($kontenHtml); ?></p>
    <p>Tidak di-escape: <?php echo $kontenHtml; ?></p>

</body>
</html>
<?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\sapa.blade.php ENDPATH**/ ?>