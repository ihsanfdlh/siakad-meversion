

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="hero-copy">
        <span class="eyebrow">PORTAL AKADEMIK</span>
        <h1>Kelola data akademik dengan lebih <span>mudah.</span></h1>
        <p>Selamat datang di SIAKAD. Akses data mahasiswa, dosen, dan mata kuliah dari satu tempat yang rapi.</p>
        <a class="button button-primary" href="<?php echo e(route('mahasiswa.index')); ?>">Lihat Data Akademik <span aria-hidden="true">&rarr;</span></a>
    </div>
    <div class="hero-art" aria-hidden="true">
        <div class="art-circle"></div>
        <div class="art-card art-card-main"><span class="art-icon">✦</span><strong>Data terorganisir</strong><small>Semua informasi dalam satu sistem</small></div>
        <div class="art-card art-card-small"><strong>+24%</strong><small>Efisiensi pengelolaan</small></div>
    </div>
</section>

<section class="stats-grid" aria-label="Ringkasan data akademik">
    <a class="stat-card" href="<?php echo e(route('mahasiswa.index')); ?>">
        <span class="stat-icon icon-blue">♙</span>
        <span class="stat-label">Mahasiswa</span>
        <strong><?php echo e(number_format($counts['mahasiswa'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
    <a class="stat-card" href="<?php echo e(route('dosen.index')); ?>">
        <span class="stat-icon icon-purple">♧</span>
        <span class="stat-label">Dosen</span>
        <strong><?php echo e(number_format($counts['dosen'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
    <a class="stat-card" href="<?php echo e(route('jurusan.index')); ?>">
        <span class="stat-icon icon-blue">⁜</span>
        <span class="stat-label">Jurusan</span>
        <strong><?php echo e(number_format($counts['jurusan'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
    <a class="stat-card" href="<?php echo e(route('prodi.index')); ?>">
        <span class="stat-icon icon-green">◫</span>
        <span class="stat-label">Profram Studi</span>
        <strong><?php echo e(number_format($counts['prodi'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
    <a class="stat-card" href="<?php echo e(route('matakuliah.index')); ?>">
        <span class="stat-icon icon-orange">▦</span>
        <span class="stat-label">Mata Kuliah</span>
        <strong><?php echo e(number_format($counts['matakuliah'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
    <a class="stat-card" href="<?php echo e(route('ruang.index')); ?>">
        <span class="stat-icon icon-green">⌂</span>
        <span class="stat-label">Ruangan</span>
        <strong><?php echo e(number_format($counts['ruang'])); ?></strong>
        <span class="stat-link">Lihat data &rarr;</span>
    </a>
</section>

<section class="section-heading home-heading">
    <div><span class="eyebrow">FITUR UTAMA</span><h2>Semua yang Anda butuhkan</h2></div>
</section>
<div class="feature-grid">
    <a class="feature-card" href="<?php echo e(route('mahasiswa.index')); ?>"><span class="feature-icon icon-blue">♙</span><h3>Mahasiswa</h3><p>Kelola identitas dan informasi akademik mahasiswa.</p><span class="feature-link">Kelola data &rarr;</span></a>
    <a class="feature-card" href="<?php echo e(route('dosen.index')); ?>"><span class="feature-icon icon-purple">♧</span><h3>Dosen</h3><p>Perbarui data dosen dan informasi kontak dengan mudah.</p><span class="feature-link">Kelola data &rarr;</span></a>
    <a class="feature-card" href="<?php echo e(route('jurusan.index')); ?>"><span class="feature-icon icon-orange">▦</span><h3>Jurusan</h3><p>Atur daftar jurusan, kepala jurusan dan sekretris jurusan.</p><span class="feature-link">Kelola data &rarr;</span></a>
    <a class="feature-card" href="<?php echo e(route('prodi.index')); ?>"><span class="feature-icon icon-blue">♙</span><h3>Program Studi</h3><p>Kelola program studi.</p><span class="feature-link">Kelola data &rarr;</span></a>
    <a class="feature-card" href="<?php echo e(route('matakuliah.index')); ?>"><span class="feature-icon icon-purple">♧</span><h3>Mata Kuliah</h3><p>Atur daftar mata kuliah, SKS, dan semester perkuliahan.</p><span class="feature-link">Kelola data &rarr;</span></a>
    <a class="feature-card" href="<?php echo e(route('ruang.index')); ?>"><span class="feature-icon icon-orange">▦</span><h3>Ruangan Belajar</h3><p>Atur daftar ruang belajar, lokasi gedung, lantai dan kapasitas.</p><span class="feature-link">Kelola data &rarr;</span></a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/welcome.blade.php ENDPATH**/ ?>