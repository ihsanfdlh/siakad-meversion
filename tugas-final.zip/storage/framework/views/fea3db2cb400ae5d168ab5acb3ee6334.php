
<?php $__env->startSection('title', 'Detail Mahasiswa ' . $mahasiswa->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="section-heading">
    <a class="back-link" href="<?php echo e(route('mahasiswa.index')); ?>">&larr; Kembali ke mahasiswa</a>
</div>
<div class="table-card">
    <div class="table-scroll"><table>
        
        <tr>
            <td colspan=2 align=center><h2>DETAIL BIODATA - <?php echo e($mahasiswa->nama); ?></h2></td>
        </tr>
        <tr>
            <td>Nama </td>
            <td><strong><?php echo e($mahasiswa->nama); ?></strong></td>
        </tr>
        <tr>
            <td>Tempat Lahir </td>
            <td><?php echo e($mahasiswa->tempat_lahir); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir </td>
            <td><?php echo e($mahasiswa->tanggal_lahir); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin </td>
            <td><?php echo e($mahasiswa->jenis_kelamin); ?></td>
        </tr>
        <tr>
            <td>Agama </td>
            <td><?php echo e($mahasiswa->agama); ?></td>
        </tr>
        <tr>
            <td>Alamat Domisili </td>
            <td><?php echo e($mahasiswa->alamat); ?></td>
        </tr>
        <tr>
            <td>No Telepone </td>
            <td><?php echo e($mahasiswa->no_telp); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo e($mahasiswa->email); ?></td>
        </tr>
        <tr>
            <td>Tahun Masuk </td>
            <td><?php echo e($mahasiswa->angkatan); ?></td>
        </tr>
        <tr>
            <td>Semester </td>
            <td><?php echo e($mahasiswa->semester); ?></td>
        </tr>
        <tr>
            <td>Program Studi </td>
            <td><?php echo e($mahasiswa->prodi?->nama ?? 'Prodi tidak ditemukan'); ?></td>
        </tr>
    </table></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\mahasiswa\show.blade.php ENDPATH**/ ?>