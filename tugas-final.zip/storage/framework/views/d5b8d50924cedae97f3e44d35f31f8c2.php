```blade
<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
</head>

<body>

    <h2>Data Mahasiswa</h2>

    
    <?php if(session('success')): ?>
        <p>
            <?php echo e(session('success')); ?>

        </p>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
        <p>
            <?php echo e(session('error')); ?>

        </p>
    <?php endif; ?>


    <p>
        <a href="/mahasiswa2/tambah">
            Tambah Mahasiswa
        </a>

        |

        <a href="/query-builder/filter">
            Filter Semester >= 3
        </a>

        |

        <a href="/statistik-prodi">
            Statistik Prodi
        </a>
    </p>


    <table border="1" cellpadding="8">

        <tr>
            <th>ID</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>Semester</th>
            <th>ID Prodi</th>
            <th>Aksi</th>
        </tr>


        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>

                <td>
                    <?php echo e($mahasiswa->id_mahasiswa); ?>

                </td>

                <td>
                    <?php echo e($mahasiswa->nim); ?>

                </td>

                <td>
                    <?php echo e($mahasiswa->nama); ?>

                </td>

                <td>
                    <?php echo e($mahasiswa->semester); ?>

                </td>

                <td>
                    <?php echo e($mahasiswa->id_prodi); ?>

                </td>

                <td>

                    <a href="/mahasiswa2/update/<?php echo e($mahasiswa->id_mahasiswa); ?>">
                        Update
                    </a>

                    |

                    <a
                        href="/mahasiswa2/delete/<?php echo e($mahasiswa->id_mahasiswa); ?>"
                        onclick="return confirm('Yakin ingin menghapus data ini?')"
                    >
                        Delete
                    </a>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="6">
                    Data mahasiswa tidak ditemukan.
                </td>

            </tr>

        <?php endif; ?>

    </table>

</body>
</html>
```
<?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/demo/query-builder.blade.php ENDPATH**/ ?>