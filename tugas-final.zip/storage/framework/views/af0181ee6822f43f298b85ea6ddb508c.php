
<?php $__env->startSection('title', 'Tambah Mata Kuliah'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-heading"><a class="back-link" href="<?php echo e(route('matakuliah.index')); ?>">&larr; Kembali ke mata kuliah</a><span class="eyebrow">DATA MATA KULIAH</span><h1>Tambah Mata Kuliah</h1><p>Isi informasi berikut untuk menambahkan mata kuliah baru.</p></div>
<?php if($errors->any()): ?><div class="alert alert-error"><strong>Periksa kembali data Anda:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
<form class="form-card" action="<?php echo e(route('matakuliah.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field"><label for="kode_mk">Kode Mata Kuliah</label><input id="kode_mk" type="text" name="kode_mk" value="<?php echo e(old('kode_mk')); ?>" placeholder="Contoh: IF101" required></div>
            <div class="field"><label for="nama_mk">Nama Mata Kuliah</label><input id="nama_mk" type="text" name="nama_mk" value="<?php echo e(old('nama_mk')); ?>" placeholder="Nama mata kuliah" required></div>
            <div class="field"><label for="sks">SKS</label><input id="sks" type="number" name="sks" value="<?php echo e(old('sks')); ?>" min="1" max="6" placeholder="2 - 4" required></div>
            <div class="field"><label for="semester">Semester</label><input id="semester" type="number" name="semester" value="<?php echo e(old('semester')); ?>" min="1" max="14" placeholder="1 - 14" required></div>
            <div class="field">
                <label for="dosen_id">Dosen</label>
                <select id="dosen_id" name="dosen_id">
                    <option value="">-- Pilih Dosen --</option>

                    <?php $__currentLoopData = $pengampu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dsn->id); ?>">
                            <?php echo e($dsn->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="field">
                <label for="id_prodi">Prodi</label>
                <select id="id_prodi" name="id_prodi">
                    <option value="">-- Pilih Prodi --</option>

                    <?php $__currentLoopData = $perodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($prodi->id); ?>">
                            <?php echo e($prodi->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
        </div>
        <div class="form-actions"><a class="button button-secondary" href="<?php echo e(route('matakuliah.index')); ?>">Batal</a><button class="button button-primary" type="submit">Simpan Mata Kuliah</button></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/matakuliah/create.blade.php ENDPATH**/ ?>