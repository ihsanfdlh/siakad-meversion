
<?php $__env->startSection('title', 'Ruangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="section-heading">
    <div><span class="eyebrow">DATA AKADEMIK</span><h1>Daftar Ruang</h1><p>Kelola informasi Ruang yang terdaftar di sistem.</p></div>
    <a class="button button-primary" href="<?php echo e(route('ruang.create')); ?>">+ Tambah Ruang</a>
</div>
<?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="table-card">
    <div class="table-top"><strong>Data Ruang</strong><span class="record-count"><?php echo e($data->count()); ?> data</span></div>
    <div class="table-scroll"><table>
        <thead><tr><th>Nomor Ruangan</th><th>Lokasi</th><th>Lantai</th><th>Kapasitas</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td><span class="code-pill"><?php echo e($ruang->nomor); ?></span></td><td><strong><?php echo e($ruang->lokasi); ?></strong></td><td><?php echo e($ruang->lantai); ?></td><td><?php echo e($ruang->kapasitas); ?> Orang</td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td class="empty-state" colspan="7"><strong>Belum ada data Ruangan</strong><span>Tambahkan ruangan pertama untuk mulai mengelola data.</span></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\ruang\index.blade.php ENDPATH**/ ?>