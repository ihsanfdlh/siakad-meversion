

<?php $__env->startSection('judul', 'Daftar Mahasiswa'); ?>
<?php $__env->startSection('konten'); ?>
    <h1>Daftar Siswa</h1>
    <a href="<?php echo e(route('akademik.mapel.index')); ?>">Ke Daftar Mata Pelajaran</a>
    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Prodi</th>
                <th>Semester</th>
                <th>Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr style="background-color: <?php echo e($loop->even ? '#f2f2f2' : '#ffffff'); ?>">
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($siswa->nim); ?></td>
                <td><?php echo e($siswa->nama); ?></td>
                <td><?php echo e($siswa->prodi); ?></td>
                <td>
                    <?php switch(true):
                        case ($siswa->semester <= 2): ?>
                            <span>Mahasiswa Baru</span>
                            <?php break; ?>
                        <?php case ($siswa->semester >= 7): ?>
                            <span>Tingkat Akhir</span>
                            <?php break; ?>
                        <?php default: ?>
                            <span>Mahasiswa Aktif</span>
                    <?php endswitch; ?>
                </td>
                <td><a href="<?php echo e(route('akademik.siswa.show', $siswa->id)); ?>">Lihat Detail</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Belum ada data mahasiswa.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/siswa/index.blade.php ENDPATH**/ ?>