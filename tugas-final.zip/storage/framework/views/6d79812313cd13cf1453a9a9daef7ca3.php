
<?php $__env->startSection('title', 'Mata Kuliah'); ?>

<?php $__env->startSection('content'); ?>
<div class="section-heading"><div><span class="eyebrow">DATA AKADEMIK</span><h1>Daftar Mata Kuliah</h1><p>Kelola mata kuliah yang tersedia di setiap semester.</p></div><a class="button button-primary" href="<?php echo e(route('matakuliah.create')); ?>">+ Tambah Mata Kuliah</a></div>
<?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="table-card"><div class="table-top"><strong>Data mata kuliah</strong><span class="record-count"><?php echo e($matkul->count()); ?> data</span></div><div class="table-scroll"><table>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode MK</th>
                <th>Nama Mata Kuliah</th>
                <th>SKS</th>
                <th>Semester</th>
                <th>Dosen Pengampu</th>
                <th>Prodi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matakuliah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="muted"><?php echo e($loop->iteration); ?></td>
                    <td><span class="code-pill"><?php echo e($matakuliah->kode_mk); ?></span></td>
                    <td><strong><?php echo e($matakuliah->nama_mk); ?></strong></td>
                    <td><?php echo e($matakuliah->sks); ?></td>
                    <td><span class="status-pill"><?php echo e($matakuliah->semester); ?></span></td>
                    <td><?php echo e($matakuliah->dosen->nama ?? 'Belum ada dosen'); ?></td>
                    <td><?php echo e($matakuliah->prodi->nama ?? 'Belum ada prodi'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td class="empty-state" colspan="7"><strong>Belum ada data mata kuliah</strong><span>Tambahkan mata kuliah pertama untuk mulai mengelola data.</span></td></tr>
            <?php endif; ?>
        </tbody>
    </table></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\matakuliah\index.blade.php ENDPATH**/ ?>