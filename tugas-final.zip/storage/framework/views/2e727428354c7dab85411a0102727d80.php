<!DOCTYPE html>
<html>

<head>
    <title>Tambah Mahasiswa</title>
</head>

<body>

    <h2>Tambah Data Mahasiswa</h2>


    
    <?php if($errors->any()): ?>

        <div>

            <strong>Terjadi kesalahan:</strong>

            <ul>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li>
                        <?php echo e($error); ?>

                    </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

    <?php endif; ?>


    <form
        action="/mahasiswa2/simpan"
        method="POST"
    >

        <?php echo csrf_field(); ?>


        <label>NIM</label>
        <br>

        <input
            type="text"
            name="nim"
            value="<?php echo e(old('nim')); ?>"
            required
        >

        <br><br>


        <label>Nama</label>
        <br>

        <input
            type="text"
            name="nama"
            value="<?php echo e(old('nama')); ?>"
            required
        >

        <br><br>


        <label>Tempat Lahir</label>
        <br>

        <input
            type="text"
            name="tempat_lahir"
            value="<?php echo e(old('tempat_lahir')); ?>"
            required
        >

        <br><br>


        <label>Tanggal Lahir</label>
        <br>

        <input
            type="date"
            name="tanggal_lahir"
            value="<?php echo e(old('tanggal_lahir')); ?>"
            required
        >

        <br><br>


        <label>Jenis Kelamin</label>
        <br>

        <select
            name="jenis_kelamin"
            required
        >

            <option value="">
                -- Pilih Jenis Kelamin --
            </option>

            <option
                value="Laki-laki"
                <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'selected' : ''); ?>

            >
                Laki-laki
            </option>

            <option
                value="Perempuan"
                <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'selected' : ''); ?>

            >
                Perempuan
            </option>

        </select>

        <br><br>


        <label>Agama</label>
        <br>

        <input
            type="text"
            name="agama"
            value="<?php echo e(old('agama')); ?>"
            required
        >

        <br><br>


        <label>Alamat</label>
        <br>

        <textarea
            name="alamat"
            required
        ><?php echo e(old('alamat')); ?></textarea>

        <br><br>


        <label>No. Telp</label>
        <br>

        <input
            type="text"
            name="no_telp"
            value="<?php echo e(old('no_telp')); ?>"
            required
        >

        <br><br>


        <label>Email</label>
        <br>

        <input
            type="email"
            name="email"
            value="<?php echo e(old('email')); ?>"
            required
        >

        <br><br>


        <label>Angkatan</label>
        <br>

        <input
            type="number"
            name="angkatan"
            value="<?php echo e(old('angkatan')); ?>"
            required
        >

        <br><br>


        <label>Semester</label>
        <br>

        <input
            type="number"
            name="semester"
            value="<?php echo e(old('semester')); ?>"
            required
        >

        <br><br>


        <label>Program Studi</label>
        <br>

        <select
            name="id_prodi"
            required
        >

            <option value="">
                -- Pilih Program Studi --
            </option>


            <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option
                    value="<?php echo e($prodi->id); ?>"
                    <?php echo e(old('id_prodi') == $prodi->id ? 'selected' : ''); ?>

                >

                    <?php echo e($prodi->nama); ?>

                    -
                    <?php echo e($prodi->jenjang); ?>


                </option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <br><br>


        <button type="submit">
            Simpan
        </button>

        <a href="/query-builder">
            Kembali
        </a>

    </form>

</body>

</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/demo/form-mahasiswa.blade.php ENDPATH**/ ?>