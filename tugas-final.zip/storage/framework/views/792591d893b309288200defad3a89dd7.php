
<?php $__env->startSection('judul', 'Detail Mata Pelajaran - ' . $mapel->nama_mk); ?>
<?php $__env->startSection('konten'); ?>
    <h1>Detail Mata Pelajaran</h1>
    <p><strong>Kode:</strong> <?php echo e($mapel->kode_mk); ?></p>
    <p><strong>Nama:</strong> <?php echo e($mapel->nama_mk); ?></p>
    <a href="<?php echo e(route('akademik.mapel.index')); ?>">&laquo; Kembali ke Daftar</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\mapel\show.blade.php ENDPATH**/ ?>