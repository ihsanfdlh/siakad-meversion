<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('judul', 'Aplikasi Akademik'); ?></title>
</head>
<body>
    <header>
        <h2>Sistem Informasi Akademik</h2>
        <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <hr>
    </header>

    <main>
        <?php echo $__env->yieldContent('konten'); ?>
    </main>

    <footer>
        <hr>
        <p>&copy; <?php echo e(date('Y')); ?> Praktikum Desain Web</p>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\layouts\app.blade.php ENDPATH**/ ?>