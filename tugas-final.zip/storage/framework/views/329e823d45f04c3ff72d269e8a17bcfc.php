
<?php $__env->startSection('title', 'Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="section-heading">
    <div><span class="eyebrow">DATA AKADEMIK</span><h1>Daftar Mahasiswa</h1><p>Kelola informasi mahasiswa yang terdaftar di sistem.</p></div>
    <a class="button button-primary" href="<?php echo e(route('mahasiswa.create')); ?>">+ Tambah Mahasiswa</a>
</div>
<?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="table-card">
    <div class="table-top"><strong>Data mahasiswa</strong><span class="record-count"><?php echo e($mahasiswa->count()); ?> data</span></div>
    <div class="table-scroll"><table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>No Telepone</th>
                <th>Angkatan</th>
                <th>Semester</th>
                <th>Prodi</th>
                <th>Detail</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="muted"><?php echo e($loop->iteration); ?></td>
                <td><span class="code-pill"><?php echo e($mhs->nim); ?></span></td>
                <td><strong><?php echo e($mhs->nama); ?></strong></td>
                <td><?php echo e($mhs->jenis_kelamin); ?></td>
                <td><?php echo e($mhs->no_telp); ?></td>
                <td><?php echo e($mhs->angkatan); ?></td>
                <td><span class="status-pill"><?php echo e($mhs->semester); ?></span></td>
                <td><?php echo e($mhs->prodi->nama); ?></td>
                <td><span class="code-pill""><a href="<?php echo e(route('mahasiswa.show', $mhs->id_mahasiswa)); ?>" style="text-decoration: none;">Lihat Detail</a></span></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td class="empty-state" colspan="11"><strong>Belum ada data mahasiswa</strong><span>Tambahkan mahasiswa pertama untuk mulai mengelola data.</span></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\mahasiswa\index.blade.php ENDPATH**/ ?>