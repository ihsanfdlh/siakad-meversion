<nav>
    <a href="<?php echo e(route('akademik.siswa.index')); ?>">Siswa</a> |
    <a href="<?php echo e(route('akademik.mapel.index')); ?>">Mata Pelajaran</a>
</nav>
<?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\partials\navbar.blade.php ENDPATH**/ ?>