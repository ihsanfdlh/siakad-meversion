

<?php $__env->startSection('judul', 'Daftar Mata Pelajaran'); ?>
<?php $__env->startSection('konten'); ?>
    <h1>Daftar Mata Pelajaran</h1>
    <a href="<?php echo e(route('akademik.siswa.index')); ?>">Ke Daftar Siswa</a>
    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>SKS</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr style="background-color: <?php echo e($loop->even ? '#abb6ff' : '#e0e4ff'); ?>">
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mapel->kode_mk); ?></td>
                <td><?php echo e($mapel->nama_mk); ?></td>
                <td>
                    <?php switch(true):
                        case ($mapel->sks >= 3): ?>
                            <span><strong>SKS Besar</strong></span>
                            <?php break; ?>
                        <?php default: ?>
                            <span>SKS Kecil</span>
                    <?php endswitch; ?>
                </td>
                <td><a href="<?php echo e(route('akademik.mapel.show', $mapel->id)); ?>">Lihat Detail</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">Belum ada data mata pelajaran.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\mapel\index.blade.php ENDPATH**/ ?>