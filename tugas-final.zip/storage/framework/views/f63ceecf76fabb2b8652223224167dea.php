
<?php $__env->startSection('title', 'Tambah prodi'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-heading">
    <a class="back-link" href="<?php echo e(route('prodi.index')); ?>">&larr; Kembali ke prodi</a>
    <span class="eyebrow">DATA prodi</span>
    <h1>Tambah prodi</h1>
    <p>Isi informasi berikut untuk menambahkan prodi baru.</p>
</div>
<?php if($errors->any()): ?><div class="alert alert-error">
    <strong>Periksa kembali data Anda:</strong>
    <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
</div><?php endif; ?>
<form class="form-card" action="<?php echo e(route('prodi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field"><label for="nama">Nama Program Studi</label>
                <input id="nama" type="text" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Nama Program Studi" required></div>
            <div class="field">
                <label for="jenjang">Jenjang</label>
                <select id="jenjang" name="jenjang">
                    <option value="">-- Pilih Jenjang --</option>
                        <option value="D3">Diploma 3</option>
                        <option value="D4">Diploma 4</option>
                </select>
            </div>
            <div class="field">
                <label for="id_jurusan">Jurusan</label>
                <select id="id_jurusan" name="id_jurusan">
                    <option value="">-- Pilih Jurusan --</option>

                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jrsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($jrsn->id); ?>">
                            <?php echo e($jrsn->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="field">
                <label for="id_kaprodi">Kepala Program Studi</label>
                <select id="id_kaprodi" name="id_kaprodi">
                    <option value="">-- Pilih Kepala Program Studi --</option>

                    <?php $__currentLoopData = $kaprodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kps->id); ?>">
                            <?php echo e($kps->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-actions"><a class="button button-secondary" href="<?php echo e(route('prodi.index')); ?>">Batal</a><button class="button button-primary" type="submit">Simpan prodi</button></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\prodi\create.blade.php ENDPATH**/ ?>