
<?php $__env->startSection('title', 'Tambah Jurusan'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-heading">
    <a class="back-link" href="<?php echo e(route('prodi.index')); ?>">&larr; Kembali ke Jurusan</a>
    <span class="eyebrow">DATA prodi</span>
    <h1>Tambah Jurusan</h1>
    <p>Isi informasi berikut untuk menambahkan Jurusan baru.</p>
</div>
<?php if($errors->any()): ?><div class="alert alert-error">
    <strong>Periksa kembali data Anda:</strong>
    <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
</div><?php endif; ?>
<form class="form-card" action="<?php echo e(route('jurusan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field"><label for="nama">Nama Jurusan</label>
                <input id="nama" type="text" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Nama Jurusan" required></div>
            <div class="field">
                <label for="id_kajur">Dosen</label>
                <select id="id_kajur" name="id_kajur">
                    <option value="">-- Pilih Kepala Jurusan --</option>

                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dsn->id); ?>">
                            <?php echo e($dsn->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
            <div class="field">
                <label for="id_sekjur">Dosen</label>
                <select id="id_sekjur" name="id_sekjur">
                    <option value="">-- Pilih Sekretaris Jurusan --</option>

                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dsn->id); ?>">
                            <?php echo e($dsn->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>
        </div>
        <div class="form-actions"><a class="button button-secondary" href="<?php echo e(route('jurusan.index')); ?>">Batal</a><button class="button button-primary" type="submit">Simpan Jurusan</button></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\jurusan\create.blade.php ENDPATH**/ ?>