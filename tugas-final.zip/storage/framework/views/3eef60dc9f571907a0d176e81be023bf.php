
<?php $__env->startSection('title', 'Detail Dosen ' . $dosen->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="section-heading">
    <a class="back-link" href="<?php echo e(route('dosen.index')); ?>">&larr; Kembali ke dosen</a>
</div>
<div class="table-card">
    <div class="table-scroll"><table>
        
        <tr>
            <td colspan=2 align=center><h2>DETAIL BIODATA - <?php echo e($dosen->nama); ?></h2></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td><strong><?php echo e($dosen->nama); ?></strong></td>
        </tr>
        <tr>
            <td>Pendidikan Terakhir</td>
            <td><strong><?php echo e($dosen->pendidikan_terakhir); ?></strong></td>
        </tr>
        <tr>
            <td>NIP </td>
            <td><?php echo e($dosen->nip); ?></td>
        </tr>
        <tr>
            <td>Tanggal Lahir </td>
            <td><?php echo e($dosen->tanggal_lahir); ?></td>
        </tr>
        <tr>
            <td>Jenis Kelamin </td>
            <td><?php echo e($dosen->jenis_kelamin); ?></td>
        </tr>
        <tr>
            <td>Agama </td>
            <td><?php echo e($dosen->agama); ?></td>
        </tr>
        <tr>
            <td>Alamat </td>
            <td><?php echo e($dosen->alamat); ?></td>
        </tr>
        <tr>
            <td>No Telepone </td>
            <td><?php echo e($dosen->no_telp); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo e($dosen->email); ?></td>
        </tr>
    </table></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\dosen\show.blade.php ENDPATH**/ ?>