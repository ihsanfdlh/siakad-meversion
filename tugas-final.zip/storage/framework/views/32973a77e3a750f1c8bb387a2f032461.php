<!DOCTYPE html>
<html>
<head>
    <title>Statistik Akademik</title>
</head>
<body>

    <h1>Statistik Akademik</h1>

    <p>Halaman statistik akademik mahasiswa.</p>

</body>
</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\akademik\statistik.blade.php ENDPATH**/ ?>