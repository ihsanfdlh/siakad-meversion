
<?php $__env->startSection('title', 'Jurusan'); ?>
<?php $__env->startSection('content'); ?>
<div class="section-heading">
    <div><span class="eyebrow">DATA AKADEMIK</span><h1>Daftar Jurusan</h1><p>Kelola informasi Jurusan yang terdaftar di sistem.</p></div>
    <a class="button button-primary" href="<?php echo e(route('jurusan.create')); ?>">+ Tambah Jurusan</a>
</div>
<?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
<div class="table-card">
    <div class="table-top"><strong>Data Jurusan</strong><span class="record-count"><?php echo e($data->count()); ?> data</span></div>
    <div class="table-scroll"><table>
        <thead><tr><th>No</th><th>Nama</th><th>Kepala Jurusan</th><th>Sekretaris Jurusan</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jrsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td class="muted"><?php echo e($loop->iteration); ?></td><td><strong><?php echo e($jrsn->nama); ?></strong></td><td><?php echo e($jrsn->kajur->nama ?? 'Belum ada Kepala Jurusan'); ?></td><td><?php echo e($jrsn->sekjur->nama ?? 'Belum ada Sekretaris Jurusan'); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td class="empty-state" colspan="7"><strong>Belum ada data Jurusan</strong><span>Tambahkan Jurusan pertama untuk mulai mengelola data.</span></td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/jurusan/index.blade.php ENDPATH**/ ?>