
<?php $__env->startSection('title', 'Tambah Ruangan'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-heading"><a class="back-link" href="<?php echo e(route('ruang.index')); ?>">&larr; Kembali ke ruangan</a><span class="eyebrow">DATA RUANGAN</span><h1>Tambah Ruangan</h1><p>Isi informasi berikut untuk menambahkan ruangan baru.</p></div>
<?php if($errors->any()): ?><div class="alert alert-error"><strong>Periksa kembali data Anda:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
<form class="form-card" action="<?php echo e(route('ruang.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field"><label for="nomor">Nomor Ruangan</label><input id="nomor" type="text" name="nomor" value="<?php echo e(old('nomor')); ?>" placeholder="Contoh: 101" required></div>
            <div class="field"><label for="lokasi">Lokasi Ruangan (Gedung)</label><input id="lokasi" type="text" name="lokasi" value="<?php echo e(old('lokasi')); ?>" placeholder="Nama Gedung" required></div>
            <div class="field"><label for="lantai">Lantai</label><input id="lantai" type="number" name="lantai" value="<?php echo e(old('lantai')); ?>" placeholder="1 - 5" required></div>
            <div class="field"><label for="kapasitas">Kapasitas</label><input id="kapasitas" type="number" name="kapasitas" value="<?php echo e(old('kapasitas')); ?>" placeholder="Contoh : 50 Orang" required></div>
        </div>
        <div class="form-actions"><a class="button button-secondary" href="<?php echo e(route('ruang.index')); ?>">Batal</a><button class="button button-primary" type="submit">Simpan Ruangan</button></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\ruang\create.blade.php ENDPATH**/ ?>