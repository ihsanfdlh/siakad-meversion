```blade
<!DOCTYPE html>
<html>

<head>
    <title>Statistik Prodi</title>
</head>

<body>

    <h2>
        Statistik Jumlah Mahasiswa per Prodi
    </h2>


    <p>
        <a href="/query-builder">
            Kembali ke Data Mahasiswa
        </a>
    </p>


    <table border="1" cellpadding="8">

        <tr>
            <th>No</th>
            <th>Program Studi</th>
            <th>Jenjang</th>
            <th>Jumlah Mahasiswa</th>
        </tr>


        <?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>

                <td>
                    <?php echo e($index + 1); ?>

                </td>

                <td>
                    <?php echo e($item->nama); ?>

                </td>

                <td>
                    <?php echo e($item->jenjang); ?>

                </td>

                <td>
                    <?php echo e($item->jumlah); ?>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="4">
                    Data tidak ditemukan.
                </td>

            </tr>

        <?php endif; ?>

    </table>

</body>

</html>
```
<?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/demo/statistik-prodi.blade.php ENDPATH**/ ?>