<!DOCTYPE html>
<html>
<head>
    <title>Profil Mahasiswa</title>
</head>
<body>

    <h1>Profil Mahasiswa</h1>

    <p>Nama: <?php echo e($nama); ?></p>
    <p>NIM: <?php echo e($nim); ?></p>
    <p>Prodi: <?php echo e($prodi); ?></p>

</body>
</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\profil.blade.php ENDPATH**/ ?>