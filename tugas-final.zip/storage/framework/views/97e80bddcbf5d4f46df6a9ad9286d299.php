
<?php $__env->startSection('title', 'Tambah Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="form-heading"><a class="back-link" href="<?php echo e(route('mahasiswa.index')); ?>">&larr; Kembali ke mahasiswa</a><span class="eyebrow">DATA MAHASISWA</span><h1>Tambah Mahasiswa</h1><p>Isi informasi berikut untuk menambahkan mahasiswa baru.</p></div>
<?php if($errors->any()): ?><div class="alert alert-error"><strong>Periksa kembali data Anda:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
<form class="form-card" action="<?php echo e(route('mahasiswa.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field">
                <label for="nim">NIM</label>
                <input id="nim" type="text" name="nim" value="<?php echo e(old('nim')); ?>" placeholder="Contoh: 2301001" required>
            </div>
            <div class="field">
                <label for="nama">Nama Mahasiswa</label>
                <input id="nama" type="text" name="nama" value="<?php echo e(old('nama')); ?>" placeholder="Nama lengkap" required>
            </div>
            <div class="field">
                <label for="tempat_lahir">Tempat Lahir</label>
                <input id="tempat_lahir" type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" placeholder="Tempat lahir" required>
            </div>
            <div class="field">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input id="tanggal_lahir" type="text" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" placeholder="Contoh : 9 Februari 2007" required>
            </div>
            <div class="field">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select id="jenis_kelamin" name="jenis_kelamin">
                    <option value="">-- Jenis Kelamin --</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div class="field">
                <label for="agama">Agama</label>
                <input id="agama" type="text" name="agama" value="<?php echo e(old('agama')); ?>" placeholder="Agama" required>
            </div>
            <div class="field">
                <label for="alamat">Alamat Domisili</label>
                <input id="alamat" type="text" name="alamat" value="<?php echo e(old('alamat')); ?>" placeholder="Alamat" required>
            </div>
            <div class="field">
                <label for="no_telp">No Telepone</label>
                <input id="no_telp" type="tel" name="no_telp" value="<?php echo e(old('no_telp')); ?>" placeholder="Contoh: 081234567890" required>
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="xyzbcaa@gmail.com" required>
            </div>
            <div class="field">
                <label for="angkatan">Angkatan</label>
                <input id="angkatan" type="number" name="angkatan" value="<?php echo e(old('angkatan')); ?>" placeholder="Tahun masuk" required>
            </div>
            <div class="field">
                <label for="semester">Semester</label>
                <select id="semester" name="semester">
                    <option value="">-- Pilih Semester --</option>
                        <option value="1">Semester 1</option>
                        <option value="2">Semester 2</option>
                        <option value="3">Semester 3</option>
                        <option value="4">Semester 4</option>
                        <option value="5">Semester 5</option>
                        <option value="6">Semester 6</option>
                        <option value="7">Semester 7</option>
                        <option value="8">Semester 8</option>
                        <option value="9">Semester 9</option>
                        <option value="10">Semester 0</option>
                        <option value="11">Semester 11</option>
                        <option value="12">Semester 12</option>
                        <option value="13">Semester 13</option>
                        <option value="14">Semester 14</option>
                </select>
            </div>
            <div class="field">
                <label for="id_prodi">Program Studi</label>
                <select id="id_prodi" name="id_prodi">
                    <option value="">-- Pilih Program Studi --</option>

                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($prodi->id); ?>">
                            <?php echo e($prodi->nama); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-actions"><a class="button button-secondary" href="<?php echo e(route('mahasiswa.index')); ?>">Batal</a><button class="button button-primary" type="submit">Simpan Mahasiswa</button></div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views/mahasiswa/create.blade.php ENDPATH**/ ?>