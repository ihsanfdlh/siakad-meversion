<!DOCTYPE html>
<html>
<head>
    <title>Demo XSS Laravel</title>
</head>
<body>

    <h1>Demo XSS Laravel</h1>

    <h3>Output menggunakan Blade</h3>
    <p><?php echo e($nama); ?></p>

    <h3>Output menggunakan HTML mentah</h3>
    <p><?php echo $nama; ?></p>

</body>
</html><?php /**PATH C:\Users\T480s\Documents\desain web\Praktikum-03-laravel\tugas-final\resources\views\xss.blade.php ENDPATH**/ ?>